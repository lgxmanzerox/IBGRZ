
export interface RGBColor {
  r: number;
  g: number;
  b: number;
}
